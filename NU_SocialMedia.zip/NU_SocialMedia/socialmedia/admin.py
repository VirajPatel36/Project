from django.contrib import admin
from django.contrib import messages
from socialmedia.models import Faculty_Personal_Information

# Register your models here. 
#admin.site.register(State)
# By default django admin shows only object name in listing.
# One can show multiple fields data from model
# class StateAdmin(admin.ModelAdmin):
# #By default django admin shows only object name in listing.
# #ModelAdmin also allows us  to create dynamic fields by declaring methods
#     list_display = ('name', 'acive')
#     def acive(self, obj):
#         return obj.is_active == 1  
#     acive.boolean = True
# admin.site.register(State, StateAdmin)
# You can add more option on Action dropdown
# class StateAdmin(admin.ModelAdmin):
#     list_display = ('name', 'active', 'created_on')  
#     def active(self, obj):
#         return obj.is_active == 1  
#     active.boolean = True  
#     def make_active(modeladmin, request, queryset):
#         queryset.update(is_active = 1)
#         messages.success(request, "Selected Record(s) Marked as Active Successfully !!")  
#     def make_inactive(modeladmin, request, queryset):
#         queryset.update(is_active = 0)
#         messages.success(request, "Selected Record(s) Marked as Inactive Successfully !!")  
#     admin.site.add_action(make_active, "Make Active")
#     admin.site.add_action(make_inactive, "Make Inactive")  
# admin.site.register(State, StateAdmin) 
# Disable Delete option

class Faculty_Personal_Information_Admin(admin.ModelAdmin):
    list_display = ('Name', 'Department', 'Designation' ,'active')  
    def active(self, obj):
        return obj.is_active == 1
    
    def Name(self, obj):
        str = obj.F_First_Name + " " + obj.F_Last_Name 
        return str
    
    def Designation(self, obj):
        str = obj.F_Designation 
        return str

    def Department(self, obj):
        str = obj.F_Institute_Name + " " + obj.F_Department_Name + " at " + obj.F_Cabin_Location
        return str
  
    active.boolean = True
  
    def make_active(modeladmin, request, queryset):
        queryset.update(is_active = 1)
        messages.success(request, "Selected Record(s) Marked as Active Successfully !!")
  
    def make_inactive(modeladmin, request, queryset):
        queryset.update(is_active = 0)
        messages.success(request, "Selected Record(s) Marked as Inactive Successfully !!")
  
    admin.site.add_action(make_active, "Make Active")
    admin.site.add_action(make_inactive, "Make Inactive")
  
    def has_delete_permission(self, request, obj = None):
        return False
  
admin.site.register(Faculty_Personal_Information, Faculty_Personal_Information_Admin)