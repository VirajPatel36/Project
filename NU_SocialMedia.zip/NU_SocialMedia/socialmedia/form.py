from django import forms
from socialmedia.models import User, Posts

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = "__all__"  

class Login(forms.Form):
    username = forms.CharField(max_length=20, label="Enter Username")
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta:
        model = User

class PostsForm(forms.ModelForm):
    class Meta:
        model = Posts
        fields = "__all__" 

class UpdatePostForm(forms.Form):
    text = forms.CharField(max_length= 150, label = "Update title")
    content = forms.CharField(max_length= 150, label = "Update content", widget=forms.Textarea(
        attrs={
            'rows' : 10
    }))
    class Meta:
        model = Posts

class DeletePostForm(forms.Form):
    agree = forms.BooleanField( label='Check this if you want to delete the post ', disabled = False, widget=forms.widgets.CheckboxInput( attrs={'class': 'checkbox-inline'}), help_text = "Post once deleted, won't be recovered", required = False)