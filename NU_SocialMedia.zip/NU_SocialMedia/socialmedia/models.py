from django.db import models

class User(models.Model):
    username = models.CharField(max_length=20)
    name = models.CharField(max_length = 30)
    email = models.EmailField(primary_key=True) 
    address = models.CharField(max_length = 50)
    phone = models.CharField(max_length = 10)
    password = models.CharField(max_length = 16)

class Posts(models.Model):
    postedBy = models.ForeignKey('socialmedia.User',on_delete=models.CASCADE)
    Post_Title = models.CharField(max_length = 150)
    Post_Content = models.TextField(max_length = 300)
    Post_Date = models.DateTimeField(auto_now= True)
    img = models.ImageField(upload_to='media')

class Faculty_Personal_Information(models.Model):
    F_First_Name = models.CharField(max_length=20)
    F_Middle_Name = models.CharField(max_length=20)
    F_Last_Name = models.CharField(max_length=20)
    F_Gender = models.CharField(max_length=6)
    F_Age = models.IntegerField()
    F_Address = models.CharField(max_length=20)
    F_EmailId = models.EmailField(max_length=20)
    F_Mobile_Number = models.CharField(max_length=10)
    F_Institute_Name = models.CharField(max_length=20)
    F_Department_Name = models.CharField(max_length=20)
    F_Designation = models.CharField(max_length=20)
    F_Cabin_Location = models.CharField(max_length=20)
    is_active = models.IntegerField(default = 1, blank = True, null = True, help_text ='1->Active, 0->Inactive',  choices =((1, 'Active'), (0, 'Inactive')))
