from django.shortcuts import redirect, render
# from .forms import *
from .models import *
from django.views import View
from django.views.generic import CreateView, UpdateView, DeleteView
from .form import Login, UserForm, PostsForm, UpdatePostForm,DeletePostForm
from django.urls import reverse_lazy
from django.db import connection

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import messages
from django.core.mail import send_mail

print(settings.MEDIA_URL)
class LandingPage(View):
    def get(self, request):
        return render(request, 'landingPage.html')

class UserCreate(CreateView):
    # def post(self, request): 
    #     name = request.POST['name']
    #     email = request.POST['email']
    #     address = request.POST['address']
    #     phone = request.POST['phone']
    #     User(name=name, email=email, address = address, phone =phone).save()
    #     redirect('UserCreate') 

    # def get(self, request):
    #     data = User.objects.all()
    #     return render(request,'index.html',{'data':data})
        model = User
        fields = ['name', 'email', 'phone', 'address', 'username', 'password']

class UserEdit(UpdateView):
    # def post(self, request,id):
    #     dataget = User.objects.get(id = id)  
    #     name = request.POST['name']
    #     email = request.POST['email']
    #     address = request.POST['address']
    #     phone = request.POST['phone']
    #     dataget.name = name
    #     dataget.email = email
    #     dataget.address = address
    #     dataget.phone = phone
    #     dataget.save()
    #     return redirect('UserCreate')
    
    # def get(self, request, id):
    #     dataget = User.objects.get(id = id)
    #     data = User.objects.all()
    #     return render(request,'index.html',{'dataget':dataget,'data':data})
    
        model = User
        fields = ['name', 'email', 'phone', 'address', 'username', 'password'] 
        template_name = "editInfo.html"
        success_url = 'dashboard'

class UserDelete(DeleteView):
    model = User
    success_url = 'dashboard'
    
class RegisterUser(View):
    def get(self, request):
        context ={}
        context['form']= UserForm()
        return render(request, "register.html", context)
    
    def post(self, request):
        # if request.method == 'POST':
        username = request.POST['username']
        name = request.POST['name']
        email = request.POST['email']
        address = request.POST['address']
        phone = request.POST['phone']
        password = request.POST['password']
        User(name=name,
                email=email,
                address = address,
                phone =phone, username = username, password = password).save()
        messages.success(request, "You have registered successfully" )
        send_mail("Success","You have successfully registered!","patelviraj036@gmail.com",[email])
        context = {}
        context['username'] = username
        return render(request, "welcome.html", context) 

class WelcomeView(View):
    def get(self, request): 
        context = {}
        context['username'] = request.session.get('username')
        query = "SELECT * FROM socialmedia_posts WHERE postedBy_id = '" + request.session.get('userId') +"'"
        foundPosts = Posts.objects.raw(query)
        userPosts = []
        for obj in foundPosts:
            # print (obj.email + " " + obj.password)
            userPosts.append(obj)
        context['userPosts'] = userPosts
        context['userId'] = request.session.get('userId')
        print(request.session.get('userId'))
        # request.session['username'] = request.session.get('username')
        return render(request, "welcome.html", context)
    
class LoginView(View):
    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username)
        query = "SELECT * FROM socialmedia_user WHERE username = '" + username +"'" 
        print(query)
        foundUser = User.objects.raw(query)
        
        # cursor = connection.cursor()
        # raw_query = "write your query here"
        # cursor.execute(query)
        # cursor.execute("SELECT * FROM socialmedia_user WHERE username ='%s'", [username])
        # data = cursor.fetchall()
        name = ''
        userPass = ''
        uid = ''
        for obj in foundUser:
            # print (obj.email + " " + obj.password)
            name = obj.username
            userPass = obj.password
            uid = obj.email
        
        if userPass == password:
            request.session['username'] = name
            request.session['userId'] = uid
            request.session.save()
            return redirect("welcome")
        else:
            context = {}
            context['form'] = Login()
            context['error'] = 'Either username or password is incorrect'
            return render(request, 'login.html', context)
        # print(foundUser) 
    
    def get(self, request):
        context = {}
        context['form'] = Login()
        return render(request, "login.html", context)
    
class PostView(View):
    def get(self, request):
        context = {}
        context['form'] = PostsForm()
        context['username'] = request.session.get('username')
        return render(request, "makeapost.html", context)
    
    def post(self, request):
        text = request.POST['Post_Title']
        uid = request.session.get('userId')
        content = request.POST['Post_Content']
        print(request.FILES)
        messages.success(request, "Post Added successfully" )
        
        # form = PostsForm(request.POST, request.FILES)
        # if form.is_valid():
        #     print(request.POST)
        #     form.save()
        # else:
        #     print("error")
        Posts(Post_Title = text, postedBy_id = uid, Post_Content = content, img = request.FILES['img']).save()
        return redirect('welcome')
    
class UpdatePost(View):
    def get(self, request, id):
        query = "SELECT * from socialmedia_posts WHERE postedBy_id = '" + request.session.get('userId') + "' and id = '" + str(id) + "'"
        text = ""
        posts = Posts.objects.raw(query)
        for obj in posts:
        # print (obj.email + " " + obj.password)
            text = obj.text
        context = {}
        context['form'] = UpdatePostForm({'text': text})
        context['username'] = request.session.get('username')
        return render(request, "updatePost.html", context)
        

    def post(self, request, id):
        text = request.POST['text']
        uid = request.session.get('userId')
        # username = request.POST.get('username')
        query = "SELECT * from socialmedia_posts WHERE postedBy_id = '" + request.session.get('userId') + "' and id = '" + str(id) + "'"
        posts = Posts.objects.raw(query)
        for obj in posts:
        # print (obj.email + " " + obj.password)
            obj.text = text
            obj.save()
        # Posts(text = text, postedBy_id = uid).save()
        return redirect('welcome')
    
class DeletePost(View):
    def get(self, request, id):
        context = {}
        context['form'] = DeletePostForm()
        return render(request, "confirmDelete.html", context)
        

    def post(self, request, id): 
        # username = request.POST.get('username')
        query = "SELECT * from socialmedia_posts WHERE postedBy_id = '" + request.session.get('userId') + "' and id = '" + str(id) + "'"
        posts = Posts.objects.raw(query)
        agree = request.POST.get('agree')
        print(agree)
        if agree == "on":
            for obj in posts: 
                obj.delete()
        # Posts(text = text, postedBy_id = uid).save()
        return redirect('welcome')